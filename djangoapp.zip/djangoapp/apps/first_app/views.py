from django.shortcuts import render, HttpResponse, redirect

def index(request):
    response="Blog list"
    return HttpResponse(response)
def new(request):
    response="MAKE A NEW BLOG"
    return HttpResponse(response)
def create(request):
    return redirect("/")
def show(request):
    response="Blog #{{x}}"
    return HttpResponse(response)
def edit(request):
    response="Edit BLog #{{x}}"
    return HttpResponse(response)
def delete(request):
    return("/")
# Create your views here.
