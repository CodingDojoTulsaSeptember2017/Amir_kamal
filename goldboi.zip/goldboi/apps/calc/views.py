from django.shortcuts import render, redirect #flash
import random
def index(request):
    return render(request,"goldboi/index.html")
def add(request):
    if request.POST["farm"]:
        farm=random.randomint(10,21)
        request.session["gold"]=request.session["gold"]+farm
        #flash("you found "+farm+" at the farm.")
    elif request.POST["cave"]:
        cave=random.randomint(5,11)
        request.session["gold"]=request.session["gold"]+cave
        #flash("you found "+cave+" at the cave.")
    elif request.POST["home"]:
        home=random.randomint(1,6)
        request.session["gold"]=request.session["gold"]+home
        #flash("you found "+home+" at the home.")
    elif request.POST["casino"]:
        casino=random.randomint(-50,51)
        request.session["gold"]=request.session["gold"]+casino
        #if casino<0:
            #flash("you lost "+casino+" at the casino")
        #else:
            #flash("you gained "+casino+" at the casino")
        
    return redirect("/")
# Create your views here.
