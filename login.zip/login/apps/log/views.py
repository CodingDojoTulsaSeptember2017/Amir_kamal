from django.shortcuts import render, redirect

def index(request):
    return render(request,'login/index.html')
def create(request):
    return render(request,"login/create.html")
def add(request):

    return redirect("/")
def show(request):
    if request.GET["sort"]=="first":
        context={
            message
        }
    elif request.GET["sort"]=="last":
    elif request.GET["sort"]=="all":
    elif request.GET["sort"]=="alpha":
    elif request.GET["sort"]=="create":
        return redirect("/create")
# Create your views here.
