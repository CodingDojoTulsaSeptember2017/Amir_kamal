from django.shortcuts import render, HttpResponse,redirect

def index(request):
    response="BLOG!"
    return HttpResponse(response)
def new(response):
    response="NEW BLOG!"
    return HttpResponse(response)
def create(response):
    return redirect("/")

def show(request):
    response="{{number}}"
    return HttpResponse(response)
def edit(request):
    response="EDIT {{number}}"
    return HttpResponse(response)
def delete(request):
    return redirect("/")

# Create your views here.
