from django.shortcuts import render, HttpResponse, redirect

def user(request):
    response="USER"
    return HttpResponse(response)

def register(request):
    response="Register"
    return HttpResponse(response)

def login(request):
    response="login"
    return HttpResponse(response)

def nuser(request):
    response="new usre"
    return HttpResponse(response)

# Create your views here.
