from django.apps import AppConfig


class SurveyConfig(AppConfig):
    name = 'survey'
