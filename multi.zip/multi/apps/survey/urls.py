from django.conf.urls import url
from . import views

urlpattern=[
    url(r"^survey$",views.survey),
    url(r"^survey/new$",views.snew)
]