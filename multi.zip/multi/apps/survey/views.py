from django.shortcuts import render, HttpResponse, redirect

def survey(request):
    response="SURVEY"
    return HttpResponse(response)

def snew(request):
    response="NEW SURVEY"
    return HttpResponse(response)

# Create your views here.
