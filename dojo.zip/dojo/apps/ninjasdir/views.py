from django.shortcuts import render, redirect

def index(respest):

def create(respest):

def delete(request):
# Create your views here.
