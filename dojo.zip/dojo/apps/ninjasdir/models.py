from __future__ import unicode_literals
from django.db import models

class dojo(model.Model):
    dojo=model.CharField(max_length=255)
    city=model.CharField(max_length=255)
    state=model.CharField(max_length=255)

class ninja(model.Model):
    ninja=model.CharField(max_length=255)
    dojo=model.ForeignKey(dojo,relate_name="ninja")

# Create your models here.
