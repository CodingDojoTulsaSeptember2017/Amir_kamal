from django.conf.urls import url
from . import views

urlpatters=[
    url(r"^$",views.index),
    url(r"^create",views.create)
    url(r"^delete",views.delete)
]