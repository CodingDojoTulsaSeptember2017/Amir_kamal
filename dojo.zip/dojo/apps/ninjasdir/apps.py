from django.apps import AppConfig


class NinjasdirConfig(AppConfig):
    name = 'ninjasdir'
