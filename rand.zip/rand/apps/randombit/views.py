from django.shortcuts import render, HttpResponse, redirect
from django.utils.crypto import get_random_string
def index(request):
    context={
        'words':get_random_string(length=14)
    }
    request.session["count"]=request.session["count"]+1
    return render(request,"rand/index.html",context)
def count(request):
        request.session["count"]=0
        return redirect("/")
# Create your views here.
