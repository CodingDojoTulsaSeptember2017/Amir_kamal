from django.apps import AppConfig


class RandombitConfig(AppConfig):
    name = 'randombit'
