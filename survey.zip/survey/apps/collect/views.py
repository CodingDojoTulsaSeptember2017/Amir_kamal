from django.shortcuts import render, redirect ,HttpResponse

def index(request):
    return render(request,"survey/index.html")
def store(request):
    request.session["name"]=request.POST["name"]
    request.session["dojo"]=request.POST["dojo"]
    request.session["lang"]=request.POST["lang"]
    request.session["comment"]=request.POST["comment"]
    return redirect("/show")
def show(request):
    return render(request,"survey/show.html")
# Create your views here.
