from django.shortcuts import render, redirect

def index(request):
    return render(request,"buy/index.html")
def buy(request):

    request.session["cost"]=request.session["cost"]+(request.POST["quantity"]*request.POST["price"])
    request.session["quantity"]=request.POST["quantity"]
    return redirect("/cart")
def cart(request):
    return render(request,"buy/cart.html")

# Create your views here.
