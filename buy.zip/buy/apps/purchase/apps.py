from django.apps import AppConfig


class PurchaseConfig(AppConfig):
    name = 'purchase'
