from django.shortcuts import render,request,redirect
from time import gmtime,strftime
def index(request):
    return render(request,"word/index.html")
def create(request):
    times=strftime("%Y-%m-%d %H:%M %p", gmtime())
    request.session["count"]=request.session["count"]+1
    if request.POST["color"] is "green":
        color="green"
    elif request.POST["color"] is "red":
        color="red"
    elif request.POST["color"] is "blue":
        color="blue"
    else:
        color="black"
    if request.POST["bigboi"] is True:
        size="bold"
    else:
        size="normal"
    
    request.session["session"]=request.form["session"]+"<style>#"+request.session["count"]+"{ font-color:"+color"; font-style:"+size+";}</style>"+request.session["session"]+"<p id='"+request.session["count"] +"'>"+request.POST["word"]+" "+times+"<p>"
    return redirect("/")


# Create your views here.
